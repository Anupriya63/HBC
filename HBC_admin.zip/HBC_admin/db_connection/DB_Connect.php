<?php
    include '../db_connection/conn.php';
    
    $user = $_POST['username'];
    $pass = md5($_POST['password']);

    //Create connection

        $conn = mysqli_connect ($servername, $username, $password, $dbname);
        
    // check connection

    if(!$conn){
            die("Connection failed: ".mysqli_connect_error());
         }      

     $sql = "Select EMAIL, PASSWORD from mng_login WHERE EMAIL = '$username' and PASSWORD = '$password'";
     
     
 
 if (mysqli_query($conn, $sql)) {
    echo "LoggedIn successfully";
        } 
        
 else {
    echo "Error: Something wRONG. try again" ."<br>" . mysqli_error($conn);
       }

mysqli_close($conn);

?>
        
         
   