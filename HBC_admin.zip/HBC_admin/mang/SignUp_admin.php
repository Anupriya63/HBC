<html>
    <head>
        <meta charset="UTF-8">
        <title>HBC Bank</title>
        <link rel="stylesheet" type="text/css" href="styleHBC.css">
    </head>
    <body bgcolor="darkgray">
        
        <div id="main">
                <div id="header">
                     <div id ="logo">
                        <h2>HBC Bank</h2>
                        <h4>Hanson Bank of Canada</h4>
                     </div>

                     <div id="menubar">  
                         <ul id="menu">
                             <li class="selected"><a href="index.php"> Home </a> </li>
                         <li><a href="bankLogin.php"> Bank Login </a> </li>
                         <li><a href=""> Add New Employee </a> </li>
                         <li><a href=""> Personal Banking </a> </li>
                         </ul>
                     </div>  

                </div>
       
                
                <div id="site_content">
                    
                    <form id="admin_login_form">
                        
                        <h2> Sign Up </h2>
                        <br>
                        
                        <label> First Name </label>
                        <input type="text" name="first_name"  placeholder="Robin">
                        
                        <label> Last Name </label>
                        <input type="text" name="last_name"  placeholder="Boss">
                        
                        <br>
                        <br>
                        
                        <label> Designation </label>
                        <select name="position">
                                <option value="Manager">Manager</option>
                                <option value="Admin">Admin</option>
                                <option value="Cashier">Cashier</option>
                                <option value="HR">HR</option>
                        </select>
                        
                        <br>
                        <br>
                        
                        <label> Employee ID </label>
                        <input type="text" name="emp_Id"  placeholder="A00619">
                        
                        <br>
                        <br>
                        
                        <label> Username </label>
                        <input type="text" name="username"  placeholder="robin@domain.com">
                        
                        <br>
                        <br>
                        
                        <label> Password </label>
                        <input type="password" name="username"  placeholder="*********">
                        
                        <br>
                        <br>
                        
                        <input type="submit" name="Sign Up" value="Sign Up">
                        
                    </form>
                
                </div>    
                </div>
        </div>    
            
        </div>
    </body>
</html>




