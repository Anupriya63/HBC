<html>
    <head>
        <meta charset="UTF-8">
        <title>HBC Bank</title>
        <link rel="stylesheet" type="text/css" href="../style/styleHBC.css">
    </head>
        <?php
               include '../db_connection/DB_Connect.php'; 
        ?>
        <body bgcolor="darkgray">
        
        <div id="main">
                <div id="header">
                     <div id ="logo">
                        <h2>HBC Bank</h2>
                        <h4>Hanson Bank of Canada</h4>
                     </div>

                     <div id="menubar">  
                         <ul id="menu">
                             
                         <li><a href="index.php"> Bank Login </a> </li>
                         <li><a href="SignUp_admin.php"> Add New Employee </a> </li>
                         <li><a href=""> Personal Banking </a> </li>
                         </ul>
                     </div>  

                </div>
       
                
                <div id="site_content">
                    
                    <p>
                        Text Here
                        Text Here
                        Text Here
                        Text Here
                        Text Here
                        Text Here
                        Text Here
                        
                    </p>
                
                </div>    
                </div>
        </div>    
            
        </div>
    </body>
</html>
